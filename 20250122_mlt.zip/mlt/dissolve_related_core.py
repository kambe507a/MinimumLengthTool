# -*- coding: utf-8 -*-
'''
    This is the place, where dissolving algorithms resolve./

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

This piece of code has been taken from Dissolve Related plugin by Piotr Andryk v 1.3.

Changes include:
- using single quotes instead of double according to my private taste;
- adding some typing which is easy to figure out;
- removing progress and try/finally.

.### Włodek do zmiany:
Originally developed by P. Andryk, taken from github, adapted for the Minimum Length Tool by 
its Autor's co-author (who happens to be myself).
Notable changes:
- using single quotes instead of double according to my private taste;
- adding some typing which is easy to figure out;
- removing progress and try/finally; ###
'''

from qgis.core import (
    QgsVectorLayer,
    QgsWkbTypes,
    QgsFeature,
    QgsGeometry
)

# these two sit in common/classes module in PA's original code. I'm avoiding 
# some tedious imports here. Unchanged.
class Node:
    def __init__(self, id, point, node=None) -> None:
        self.id = id
        self.point = point
        self.node = node
        self.relation_ids = []
        self.relation_counter = 0

    def add_id(self, new_id) -> None:
        if new_id not in self.relation_ids:
            self.relation_ids.append(new_id)

class FeatureHelper:
    def __init__(self, dictHelper, shape) -> None:
        shapeID = shape.id()
        self.id = shapeID
        self.nodeList = []
        geometry = shape.geometry()

        for part in geometry.parts():
            self.nodeList.append(Node(shapeID, part[0]))
            self.nodeList.append(Node(shapeID, part[-1]))

        dictHelper[shapeID] = self

# Function creates a feature helper or returns existing one for given id
def validate_feature_helper_dict(feature_helper_dict, shape_id, shape) -> any:
    if (feature_helper_dict is None) or (shape is None):
        return
    if shape_id not in feature_helper_dict.keys():
        return FeatureHelper(feature_helper_dict, shape)
    else:
        return feature_helper_dict[shape_id]

# Function checks if point intersects other point or multipoint
def check_point_point_intersection(point, intersect) -> bool:
    for part in intersect.parts():
        if point == part:
            return True

    return False

# Function fills feature helper dictionary based on provided arcs' layer
def get_feature_helper_dict(layer) -> dict:
    feature_helper_dict = {}

    for shape in layer.getFeatures():
        FeatureHelper(feature_helper_dict, shape)

    return feature_helper_dict

class DissolveRelatedCore:
    def __init__(self, inputLayer: QgsVectorLayer, fieldNames: list[str], outputLayerName: str, splitArcs: bool):
        self.inputLayer = inputLayer
        self.fieldNames = fieldNames
        self.relationsDict = {}
        self.outputLayer = QgsVectorLayer(
            QgsWkbTypes.displayString(inputLayer.wkbType()) + '?index=yes',
            outputLayerName,
            'memory',
            crs=inputLayer.crs()
        )
        self.splitArcs = splitArcs

    def copyFeatures(self) -> None:
        self.outputLayer.dataProvider().addAttributes(self.inputLayer.fields())

        features = []
        for feature in self.inputLayer.getFeatures():
            newFeature = QgsFeature()
            newFeature.setGeometry(feature.geometry())
            newFeature.setFields(feature.fields())

            for field in feature.fields():
                newFeature[field.name()] = feature[field.name()]

            features.append(newFeature)

        self.outputLayer.startEditing()
        self.outputLayer.dataProvider().addFeatures(features)
        self.outputLayer.commitChanges()

    def getKey(self, relatedID) -> any:
        for key in self.relationsDict.keys():
            if relatedID in self.relationsDict[key]:
                return key

    def isInRelation(self, id1, id2) -> bool:
        if ((id1 in self.relationsDict.keys()) and (id2 in self.relationsDict[id1])) or \
                ((id2 in self.relationsDict.keys()) and (id1 in self.relationsDict[id2])):
            return True
        else:
            for key in self.relationsDict.keys():
                if (id1 in self.relationsDict[key]) and (id2 in self.relationsDict[key]):
                    return True
            return False

    def hasSameAttributes(self, id1, id2) -> bool:
        shp1 = self.outputLayer.getFeature(id1)
        shp2 = self.outputLayer.getFeature(id2)

        for field in self.fieldNames:
            if shp1[field] != shp2[field]:
                return False

        return True

    def getDictKeyValueList(self) -> list:
        resultList = []
        try:
            if len(self.relationsDict) == 0:
                return

            for key in self.relationsDict.keys():
                resultList.append(key)
                for item in self.relationsDict[key]:
                    resultList.append(item)
        finally:
            return resultList

    def populateRelationsDictionary(self, sourceID, relateID) -> None:
        totalUsedList = self.getDictKeyValueList()
        # If source is not used
        if sourceID not in totalUsedList:
            # If related is not used, create new relation
            if relateID not in totalUsedList:
                self.relationsDict[sourceID] = [relateID]
            # If related is used as source, append source as related
            elif relateID in self.relationsDict.keys():
                self.relationsDict[relateID].append(sourceID)
            # If related is used in other relation, append source as related to that relation
            else:
                self.relationsDict[self.getKey(relateID)].append(sourceID)
        # If source used as source
        elif sourceID in self.relationsDict.keys():
            # If related is not used, append to source
            if relateID not in totalUsedList:
                self.relationsDict[sourceID].append(relateID)
            # If related is used as source, append related with its relation
            elif relateID in self.relationsDict.keys():
                self.relationsDict[sourceID] = self.relationsDict[sourceID] + \
                                               self.relationsDict[relateID] + \
                                               [relateID]
                self.relationsDict.pop(relateID)
            # If related used as related, append parent of its relation
            else:
                relateParentID = self.getKey(relateID)
                self.relationsDict[sourceID] = self.relationsDict[sourceID] + \
                                               self.relationsDict[relateParentID] + \
                                               [relateParentID]
                self.relationsDict.pop(relateParentID)
        # If source is used as related
        else:
            # If related is not used, append to parent of source
            if relateID not in totalUsedList:
                self.relationsDict[self.getKey(sourceID)].append(relateID)
            # If related is used as source, append parent of source with its relation
            elif relateID in self.relationsDict.keys():
                sourceParentID = self.getKey(sourceID)
                if sourceParentID == relateID:
                    return

                self.relationsDict[relateID] = self.relationsDict[relateID] + \
                                               self.relationsDict[sourceParentID] + \
                                               [sourceParentID]
                self.relationsDict.pop(sourceParentID)
            # If related is used as related, append parent of source with its relation to that relation
            else:
                sourceParentID = self.getKey(sourceID)
                relateParentID = self.getKey(relateID)
                if sourceParentID == relateParentID:
                    return

                self.relationsDict[relateParentID] = \
                    self.relationsDict[relateParentID] + \
                    self.relationsDict[sourceParentID] + \
                    [sourceParentID]
                self.relationsDict.pop(sourceParentID)

    def getMultipartRelations(self) -> None:
        for shapeSource in self.outputLayer.getFeatures():
            sourceID = shapeSource.id()
            engine = QgsGeometry.createGeometryEngine(shapeSource.geometry().constGet())
            engine.prepareGeometry()

            for shapeRelate in self.outputLayer.getFeatures():
                relateID = shapeRelate.id()
                if (sourceID == relateID) or (self.isInRelation(sourceID, relateID)) or \
                        (self.hasSameAttributes(sourceID, relateID) is False):
                    continue

                # If intersected
                if engine.intersects(shapeRelate.geometry().constGet()):
                    self.populateRelationsDictionary(sourceID, relateID)

    def getSinglepartRelations(self) -> None:
        featuresHelperDict = {}
        for shapeSource in self.outputLayer.getFeatures():
            sourceID = shapeSource.id()

            if sourceID not in featuresHelperDict.keys():
                featureHelperSource = FeatureHelper(featuresHelperDict, shapeSource)
            else:
                featureHelperSource = featuresHelperDict[sourceID]

            engine = QgsGeometry.createGeometryEngine(shapeSource.geometry().constGet())
            engine.prepareGeometry()

            for shapeRelate in self.outputLayer.getFeatures():
                relateID = shapeRelate.id()
                if (sourceID == relateID) or (self.hasSameAttributes(sourceID, relateID) is False):
                    continue

                if relateID not in featuresHelperDict.keys():
                    featureHelperRelate = FeatureHelper(featuresHelperDict, shapeRelate)
                else:
                    featureHelperRelate = featuresHelperDict[relateID]

                intersect = engine.intersection(shapeRelate.geometry().constGet())
                if intersect is None:
                    continue

                for node1 in featureHelperSource.nodeList:
                    if (node1.node is None) and (node1.point == intersect):
                        for node2 in featureHelperRelate.nodeList:
                            if (node2.node is None) and (node2.point == intersect):
                                node1.node = node2
                                node2.node = node1

        # Building relationsDict based on Nodes' relations
        for featureHelper in featuresHelperDict.values():
            sourceID = featureHelper.id

            for node in featureHelper.nodeList:
                if node.node is None:  # No relations
                    continue

                relateID = node.node.id
                self.populateRelationsDictionary(sourceID, relateID)

    def getRelations(self) -> None:
        if self.splitArcs:
            self.getSinglepartRelations()
        else:
            self.getMultipartRelations()

    def createFeature(self, geometry, sourceFeature) -> QgsFeature | None:
        feature = QgsFeature(self.outputLayer.fields())
        if feature is None:
            return

        for field in self.fieldNames:
            feature[field] = sourceFeature[field]

        feature.setGeometry(geometry)
        return feature

    def mergeLines(self, geometry) -> QgsGeometry:
        newGeometry = QgsGeometry()
        newGeometry.set(geometry)
        newGeometry = QgsGeometry.mergeLines(newGeometry)
        return newGeometry

    def dissolveFeatures(self) -> None:
        newFeaturesList = []
        self.outputLayer.beginEditCommand('Dissolving features...')
        
        for key in self.relationsDict.keys():

            sourceFeature = self.outputLayer.getFeature(key)
            sourceGeometry = self.outputLayer.getGeometry(key)
            if sourceGeometry is None:
                continue

            relatedGeometryList = [sourceGeometry]

            for relatedID in self.relationsDict[key]:
                relatedGeometry = self.outputLayer.getGeometry(relatedID)
                if relatedGeometry is None:
                    continue

                relatedGeometryList.append(relatedGeometry)

            engine = QgsGeometry.createGeometryEngine(sourceGeometry.constGet())
            engine.prepareGeometry()

            newGeometry = engine.combine(relatedGeometryList)
            if newGeometry is None:
                continue

            if self.splitArcs:
                newGeometry = self.mergeLines(newGeometry)
                if newGeometry is None:
                    continue

            newFeature = self.createFeature(newGeometry, sourceFeature)
            if newFeature is None:
                continue

            newFeaturesList.append(newFeature)

        self.outputLayer.dataProvider().deleteFeatures(self.getDictKeyValueList())
        self.outputLayer.dataProvider().addFeatures(newFeaturesList)
        self.outputLayer.commitChanges()

    def execute(self) -> None:
        self.copyFeatures()
        self.getRelations()
        self.dissolveFeatures()