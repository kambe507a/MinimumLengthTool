# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtWidgets import (
    QMessageBox,
    QFileDialog
)

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
)

def LoadCsvFromDisk() -> None:
    file_path, _ = QFileDialog.getOpenFileName(
        None, 
        caption = 'Select a file:',
        directory = '',
        filter = 'CSV Files (*.csv)'
    )

    if not file_path:
        QMessageBox.information(
            None,
            'No File Selected',
            'Please select a valid file.'
        )
        return None
    else:
        QMessageBox.information(
            None,
            'Success',
            'River Attributes data loaded successfully.'
        )
        return file_path
    
def LoadLayerFromDisk(nameHint: str = '*') -> QgsVectorLayer:
    file_path, _ = QFileDialog.getOpenFileName(
        None, 
        caption = 'Select a file:',
        directory = '',
        filter = f'ESRI shp (*.shp);;*{nameHint}*;;GeoPackage (*.gpkg)'
    )

    if not file_path:
        QMessageBox.information(
            None,
            'No file selected',
            'Please select a valid file.'
        )
        return None    
    
    layerFileName = GetFileName(file_path)
    provider = _GetProvider(file_path)

    try:
        layer = QgsVectorLayer(file_path, layerFileName, provider)
        if not layer.isValid():
            raise Exception(f'The layer is invalid. File name: {file_path}')
    except Exception as ex:
        QMessageBox.information(None, 'Error:', f'Loading the layer failed: {ex}')
    else:
        presentLayers = QgsProject.instance().mapLayersByName(layer.name())

        if len(presentLayers) == 0:
            QgsProject.instance().addMapLayer(layer)
            return layer
        else:
            assert len(presentLayers) == 1, f'źle!'
            return presentLayers[0]

    return None

def _GetProvider(file_path: str) -> str:
    if file_path.endswith('shp'):
        return 'ogr'
    elif file_path.endswith('gpkg'):
        return 'gpkg'
    
def CleanUp(dir: str, files: list[str] = None, force: bool = False) -> None:

    if force == True:
        with os.scandir(dir) as it:
            for entry in it:
                if entry.is_file():
                    os.remove(entry.path)                
        return

    if files == None:
        return
    elif len(files) == 0:
        return

    fileNames = []

    for file in files:
        fileNames.append(StripExtension(file))

    remove = []        
    with os.scandir(dir) as it:
        for entry in it:
            if entry.is_file():
                if StripExtension(entry.name) in fileNames:
                    remove.append(entry.path)
                    
    for path in remove:
        os.remove(path)
        
def GetFileName(path: str, stripExtension: bool = False) -> str:
        name = os.path.basename(path)
        if not stripExtension:
            return name
        else:
            return StripExtension(name)

def StripExtension(fileName: str):
    if '.' not in fileName:
        return fileName
    else:
        i = fileName.rindex('.')
        return fileName[0:i]
    
def SeparateByCapitals(s: str) -> str:
    '''AlaMaKota -> Ala Ma Kota'''
    i = 0
    output = ''
    while i < len(s):
        if i == 0:
            output += s[i]
            i += 1
            continue
        if s[i].isupper():
            output += ' '
            output += s[i]
            i += 1
            continue
        else:
            output += s[i]
            i += 1

    return output